=== MomoPaid ===
Contributors: Tillpaid
Tags: MomoPaid,africa payment method, MTN Mobile mobile money, woocommerce MTN Mobile mobile money,MTN Mobile mobile money online, payement en ligne afrique,site ecommerce afrique
Donate link: https://tillpaid.com/momopaid
Requires at least: 4.4
Tested up to: 5.0.1
Requires PHP: 5.6
Stable tag: trunk
License: GPLv2+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

<p>Accept MTN Mobile Money payments in your shop through MomoPaid for Woocommerce.</p>

== Description ==
<p>Accept MTN Mobile  Money payments in your shop through MomoPaid for Woocommerce.</p>
<h4>Take MTN Mobile  Mobile Money payments directly on your store.</h4>
<p>The MomoPaid plugin extends WooCommerce by allowing you to make payments directly to your store via code optimized for that.</p>
<p>MomoPaid is available for :</p>
<ul>
<li>Africa</li>
</ul>
<h4>WHY CHOOSE MomoPaid?</h4>
<p>MomoPaid has no setup fees, no monthly fees, no hidden costs: you will receive what has been sent to you.</p>


== Installation ==
<h4>Automatic installation</h4>
<p>Automatic installation is the easiest option as WordPress handles the file transfers itself and you do not need to leave your web browser. to
do an automatic install of, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "MomoPaid" and click Search Plugins. Once you've found out about this plugin, click here. Most importantly, you can install it by simply clicking "Install Now".</p>
<h4>Manual installation</h4>
<p>The manual installation method involves downloading our plugin and uploading it to your web server via your favorite FTP application. The WordPress codex contains <a href="https://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation" rel="nofollow">instructions on how to do this here</a>.</p>


== Frequently Asked Questions ==
<br><strong>What is the cost for the gateway plugin?</strong>
<p>The plugin cost 18000 XOF.</p>
<br><strong>Where can I get support or talk to other users?</strong>
<p>If you get stuck, you can ask for help in the Plugin Forum.</p>
<br><strong>The plugins it is compatible with Woocommerce Subscriptions plugins?</strong>
<p>This functionality will be available soon.</p>





== Screenshots ==
1. backend configuration page
2. frontend configuration page

== Changelog ==
<h4>1.0.4</h4>
<ul>
<li>Optimisation of the plugins.</li>
<li>Add shipping amount to the total amount.</li>
</ul>
<h4>1.0.3</h4>
<ul>
<li>Optimisation of the plugins.</li>
<li>Add details on woo commerce checkout page.</li>
</ul>
<h4>1.0.2</h4>
<ul>
<li>Optimisation of the plugins.</li>
<li>Minor bugs fixed</li>
</ul>
<h4>1.0.1</h4>
<ul>
<li>Minor bugs fixed</li>
</ul>
<h4>1.0.0</h4>
<ul>
<li>First version</li>
</ul>




== Upgrade Notice ==
<p>Automatic updates should work like a charm; as always though, ensure you backup your site just in case.</p>