<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://tillpaid.com/momopaid
 * @since      3.1.6
 *
 * @package    momo_paid
 * @subpackage momo_paid/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    momo_paid
 * @subpackage momo_paid/admin
 * @author     Tillpaid <hello@tillpaid.com>
 */
class momo_paid_admin {


	/**
	 * The ID of this plugin.
	 *
	 * @since    3.1.6
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    3.1.6
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    3.1.6
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    3.1.6
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in momo_paid_loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The momo_paid_loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/momo-paid-admin.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    3.1.6
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in momo_paid_loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The momo_paid_loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/momo-paid-admin.js', array( 'jquery' ), $this->version, false );
	}

	/**
	 * Function for check if woocommerce is activated
	 */
	public function check_if_woocommerce_is_active() {
		if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
			?>
<div class=" notice notice-error">
<p>
			<?php
			esc_html_e( 'MomoPaid requiert l’activation de WooCommerce.', 'momo-paid' );
			?>
</p>
</div>
			<?php

		}
	}

	/**
	 * Add settings link
	 */
	public function link_to_settings( $links, $file ) {
		if ( 'momo-paid/momo-paid.php' === $file && current_user_can( 'manage_options' ) ) {
			$settings = array( 'settings' => '<a href="admin.php?page=wc-settings&tab=checkout&section=momo-paid">' . __( 'Réglages', 'momo-paid' ) . '</a>' );
			$links    = array_merge( $settings, $links );
		}
		return $links;
	}


}

