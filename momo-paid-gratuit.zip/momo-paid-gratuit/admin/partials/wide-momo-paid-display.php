<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://tillpaid.com/momopaid
 * @since      3.1.6
 *
 * @package    momo_paid
 * @subpackage momo_paid/admin/partials
 */

?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
