<?php
/**
 * Fired during plugin deactivation
 *
 * @link      https://tillpaid.com/momopaid
 * @since      3.1.6
 *
 * @package    Momo_Paid
 * @subpackage Momo_Paid/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      3.1.6
 * @package    Momo_Paid
 * @subpackage Momo_Paid/includes
 * @author     Tillpaid <hello@tillpaid.com>
 */
class momo_paid_deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
