<?php
/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://tillpaid.com/momopaid
 * @since      3.1.6
 *
 * @package    Momo_Paid
 * @subpackage Momo_Paid/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      3.1.6
 * @package    Momo_Paid
 * @subpackage Momo_Paid/includes
 * @author     Tillpaid <hello@tillpaid.com>
 */
class momo_paid_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'momo-paid',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
