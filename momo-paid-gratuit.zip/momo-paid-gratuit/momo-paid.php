<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://tillpaid.com/momopaid
 * @since             3.1.6
 * @package           Momo_Paid
 * @wordpress-plugin
 * Plugin Name:       MomoPaid
 * Description:       Acceptez le paiement de vos clients par MTN Mobile money sur Woocommerce.
 * Version:           3.1.6
 * Author:            TillPaid
 * Author URI:        https://tillpaid.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       momo-paid
 * Domain Path:       /languages
 * Contributors :     TillPaid
 * WC requires at least: 3.0.0
 * WC tested up to: 3.4.2
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) && ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'momo_paid_VERSION', '3.1.6' );
define( 'momo_paid_DIR', plugin_dir_path( __FILE__ ) );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-momo-paid-activator.php
 */
function activate_momo_paid() {
	require_once momo_paid_DIR . 'includes/class-momo-paid-activator.php';
	momo_paid_activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-momo-paid-deactivator.php
 */
function deactivate_momo_paid() {
	require_once momo_paid_DIR . 'includes/class-momo-paid-deactivator.php';
	momo_paid_deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_momo_paid' );
register_deactivation_hook( __FILE__, 'deactivate_momo_paid' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require momo_paid_DIR . 'includes/class-momo-paid.php';



/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    3.1.6
 */
function run_momo_paid() {

	$plugin = new momo_paid();
	$plugin->run();

}
run_momo_paid();
