<?php

// Checking if Woocommerce Plugin is activated.
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_action( 'plugins_loaded', 'momo_paid_payment_gateway' );
}

/**
 * Function custom payment gateway MomoPaid
 */
function momo_paid_payment_gateway() {
	/**
	 * The admin-specific functionality of the plugin.
	 *
	 * @link       https:/tillpaid.com/momopaid
	 * @since      3.1.6
	 *
	 * @package    Momo_Paid
	 * @subpackage Momo_Paid/payment-gateway
	 */

	/**
	 * The payment gateway main class.
	 *
	 * @package    Momo_Paid
	 * @subpackage Momo_Paid/payment-gateway
	 * @author     Tillpaid <hello@tillpaid.com>
	 */
	class momo_paid_payment_gateway extends WC_Payment_Gateway {

		/**
		 * MomoPaid Payment Gateway constructor.
		 */
		public function __construct() {

			$this->id           = 'momo-paid';
			$this->icon         = plugins_url( '../images/icons.png', __FILE__ );
			$this->method_title = __( 'MomoPaid', 'momo-paid' );
			$this->title        = $this->method_title;
			$this->has_fields   = true;
			$this->init_form_fields();
			$this->init_settings();
			$this->enabled            = $this->get_option( 'enabled' );
			$this->description        = __( 'MomoPaid: Recevez vos Paiements en ligne par MTN MOMO', 'momo-paid' );
			$this->method_description = $this->description;
			// This action hook saves the settings.
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			// Enqueue scripts for ajax.
			add_action( 'enqueue_scripts', array( $this, 'payment_scripts' ) );

			add_action( 'woocommerce_checkout_process', array( $this, 'validate_fields' ) );
			add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'save_post_meta' ) );
			add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'display_transaction_id' ), 10, 1 );
			$this->recipient_number = $this->get_option( 'recipient_number' );
			$this->recipient_name   = $this->get_option( 'recipient_name' );
            add_action( 'enqueue_scripts', array( $this, 'payments_scripts' ) );
		}

		/**
		 * Init woocommerce form fields.
		 *
		 * @return void
		 */
		public function init_form_fields() {

			$this->form_fields = array(
				'enabled'          => array(
					'title'   => __( 'Activer/Desactiver MomoPaid', 'momo-paid' ),
					'type'    => 'checkbox',
					'label'   => __( 'Activer/Desactiver MomoPaid', 'momo-Paid' ),
					'default' => 'no',
				),
				'recipient_name'   => array(
					'title'       => __( 'Identité du Bénéficiaire', 'momo-paid' ),
					'type'        => 'text',
					'description' => __( 'Nom du Bénéficiaire du paiement MTN MOMO. <u><strong>E.g :</strong></u> Marco Polo', 'momo-paid' ),
				),
				'recipient_number' => array(
					'title'       => __( 'Numero du Bénéficiaire MTN MOMO', 'momo-paid' ),
					'type'        => 'number',
					'description' => __( 'Numéro du Bénéficiaire du Paiement. <u><strong>E.g :</strong></u> 22997979797', 'momo-paid' ),
				),
			);
		}

		/**
		 * MomoPaid front payment fields.
		 *
		 * @return void
		 */
		public function payment_fields() {

			if ( is_checkout() ) {
				$momo_paid       = new momo_paid_payment_gateway( false );
				$recipient_name   = $momo_paid->recipient_name;
				$recipient_number = $momo_paid->recipient_number;
				if ( ! empty( $recipient_name ) || ! empty( $recipient_number ) ) {
					momo_paid_payment_using_mobile_solutions( $recipient_name, $recipient_number );
					$args = array(
						'type'        => 'number',
						'label'       => __( 'ID DE LA TRANSACTION MOMO', 'momo-paid' ),
						'placeholder' => __( '(09 PREMIERS CHIFFRES)', 'Momo-Paid' ),
						'required'    => true,
						'class'       => array( 'form-row-wide' ),
					);
					echo '<br/></BLOCKQUOTE><div class="momo-mtn-form">';
					woocommerce_form_field( '_momo_mtn', $args );
					echo '</div>';
					echo '<br/><div class="momo-paid-know-before">';
					echo '</div>';
					echo '<p align="right">Plugin Gratuit <br> <a href="https://www.tillpaid.com" target="_blank">TillPaid</a></p>';
echo '</p>';
				} else {
					esc_html_e( "Veuillez-bien contactez l'administrateur de ce site , un problème est survenu." );
				}
			}
		}

		/**
		 * Process payments
		 *
		 * @param  mixed $order_id Woocommerce global variables.
		 * @return array
		 */
		public function process_payment( $order_id ) {
			$order = wc_get_order( $order_id );
			$order->update_status( 'on-hold', __( 'Votre paiement doit être vérifié , merci de bien vouloir patienter.', 'moov-paid' ) );
			WC()->cart->empty_cart();
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			);
		}

		/**
		 * Validate fields.
		 *
		 * @return void
		 */
		public function validate_fields() {
			global $order_id;
			if ( is_checkout() ) {
				$radio_choice = $_POST['_momo_mtn'];
				if ( empty( $radio_choice ) || preg_match( '/(\d){9}/', $radio_choice ) == false ) {
					wc_add_notice( 'L\'ID de Transaction MTN Momo ne peut être vide et doit contenir les 09 premiers chiffres.', 'error' );
				} elseif ( strlen( utf8_decode( $radio_choice ) ) != 9 ) {
					wc_add_notice( 'La valeur ID de transaction est composé des 09 premiers chiffres , pas plus ni moins.', 'error' );
				}
			}
		}

		/**
		 *  Saving post meta.
		 *
		 * @param  mixed $order_id Woocommerce global variables.
		 * @return void
		 */
		public function save_post_meta( $order_id ) {

				$radio_choice = sanitize_text_field( wp_unslash( $_POST['_momo_mtn'] ) );
			if ( ! empty( $radio_choice ) || preg_match( '/(\d){9}/', $radio_choice ) == true ) {
				update_post_meta( $order_id, '_momo_mtn', sanitize_text_field( $radio_choice ) );
			}

		}

		/**
		 * Displays the transaction id in the details of the command.
		 *
		 * @param  mixed $order Woocommerce global variables.
		 * @return void
		 */
		public function display_transaction_id( $order ) {
			$order_data           = $order->get_data();
			$order_payment_method = $order_data['payment_method'];
			if ( 'momo-paid' == $order_payment_method ) {
				$transaction_id = get_post_meta( $order->get_id(), '_momo_mtn', true );
				echo '<div class="order_data_column"><h4>' . sprintf( esc_html( 'ID DE TRANSACTION MTN MOMO : %s ', 'momo-paid' ), esc_html( $transaction_id ) ) . '</h4></div>';
			}
		}

				/**
				 * Enqueue payments scripts in the payments gateway.
				 */
		public function payments_scripts() {
			// Compatibilty for website using Elementor plugins
			// wp_enqueue_style( 'momo-paid-styles', plugin_dir_url( __FILE__ ) . 'css/momo-paid-styles.css', array(), '1.0', 'all' );
		}
	}

}

/**
 * Add MomoPaid class to all payment gateway methods.
 *
 * @param  mixed $methods Woocommerce Default Methods.
 * @return mixed
 */
function momo_paid_add_gateway_class( $methods ) {
	$methods[] = 'momo_paid_payment_gateway';
	return $methods;
}

add_filter( 'woocommerce_payment_gateways', 'momo_paid_add_gateway_class' );

/**
 * MomoPaid function for manage mobile payments.
 *
 * @param  string  $recipient_name Recipient name.
 * @param  integer $recipient_number Recipient number.
 * @return mixed
 */
function momo_paid_payment_using_mobile_solutions( $recipient_name, $recipient_number ) {
	global $woocommerce;
	$cart_total_price = $woocommerce->cart->get_total();
	echo sprintf( __( '<strong>1°)</strong>  Envoyer <strong>%1$s</strong> correspondant au paiement de votre commande à <strong>%2$s</strong> par <strong>MTN MOMO</strong> au : <strong>%3$d</strong>.<br/><br/> <strong>2°) Verifiez le paiement en insérant l\'ID de Transaction (9 Premiers Chiffres)</strong> <br/>
    * L\'<strong>ID de transaction </strong> est un <strong>champ requis</strong> et se trouve dans l\'accusé de reception envoyé par SMS une fois votre transaction MTN MOMO effectué.</strong>.', 'momo-paid' ), wp_kses_post( $cart_total_price ), esc_html( $recipient_name ), esc_html( $recipient_number ) );
}
